<?php
require_once("../../../init.php");
require_once("../../../includes/functions.php");
require_once("../../../includes/gatewayfunctions.php");
require_once("../../../includes/invoicefunctions.php");

$gatewayModule = "yoomoney"; // Имя модуля

// Получаем параметры модуля
$gatewayParams = getGatewayVariables($gatewayModule);

if (!$gatewayParams["type"]) {
    die("Модуль не активирован");
}

// Получаем данные из запроса
$invoiceId = $_POST['label']; // ID счёта (заказа)
$transactionId = $_POST['operation_id']; // ID транзакции YooMoney
$paymentAmount = $_POST['amount']; // Сумма платежа
$paymentStatus = $_POST['unaccepted'] == 'false' ? 'Success' : 'Failed'; // Статус платежа

// Проверка ID счёта в базе WHMCS
$invoiceId = checkCbInvoiceID($invoiceId, $gatewayParams['name']);

// Проверка статуса платежа и регистрация в WHMCS
if ($paymentStatus == 'Success') {
    // Проверяем уникальность транзакции
    checkCbTransID($transactionId);

    // Добавляем оплату на счёт
    addInvoicePayment($invoiceId, $transactionId, $paymentAmount, 0, $gatewayModule);

    // Логируем успешную транзакцию
    logTransaction($gatewayParams['name'], $_POST, 'Успешно');

    // Автоматически активируем заказ после успешной оплаты
    $command = 'UpdateInvoice';
    $postData = array(
        'invoiceid' => $invoiceId,
        'status' => 'Paid',
    );
    $results = localAPI($command, $postData);

} else {
    // Логируем неуспешную транзакцию
    logTransaction($gatewayParams['name'], $_POST, 'Неуспешно');
}
?>
