<?php
if (!defined("WHMCS")) {
    die("Этот файл не может быть запущен напрямую");
}

// Основная информация о модуле
function yoomoney_MetaData()
{
    return array(
        'DisplayName' => 'Платежный шлюз YooMoney',
        'APIVersion' => '1.1', // Версия API WHMCS
    );
}

// Конфигурация модуля
function yoomoney_config()
{
    return array(
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'YooMoney',
        ),
        'walletId' => array(
            'FriendlyName' => 'Идентификатор кошелька (Wallet ID)',
            'Type' => 'text',
            'Size' => '20',
            'Description' => 'Введите ваш идентификатор кошелька YooMoney',
        ),
        'secretKey' => array(
            'FriendlyName' => 'Секретный ключ',
            'Type' => 'password',
            'Size' => '20',
            'Description' => 'Введите ваш секретный ключ для работы с API YooMoney',
        ),
    );
}

// Форма оплаты для клиента с добавленной кнопкой ссылки на API уведомлений
function yoomoney_link($params)
{
    // Данные заказа
    $invoiceId = $params['invoiceid'];
    $description = $params['description'];
    $amount = $params['amount'];
    $currency = $params['currency'];

    // Данные продавца
    $walletId = $params['walletId'];
    $secretKey = $params['secretKey'];

    // URL для возврата
    $callbackUrl = $params['systemurl'] . 'modules/gateways/callback/yoomoney.php';

    // URL для обработки платежа
    $url = "https://yoomoney.ru/quickpay/confirm.xml";

    // Формируем HTML форму для отправки на платежную страницу YooMoney
    $htmlOutput = '<form method="POST" action="' . $url . '">';
    $htmlOutput .= '<input type="hidden" name="receiver" value="' . $walletId . '">';
    $htmlOutput .= '<input type="hidden" name="formcomment" value="' . $description . '">';
    $htmlOutput .= '<input type="hidden" name="label" value="' . $invoiceId . '">';
    $htmlOutput .= '<input type="hidden" name="sum" value="' . $amount . '" data-type="number">';
    $htmlOutput .= '<input type="hidden" name="successURL" value="' . $callbackUrl . '">';
    $htmlOutput .= '<input type="hidden" name="quickpay-form" value="shop">';
    $htmlOutput .= '<input type="submit" value="Оплатить через YooMoney">';
    $htmlOutput .= '</form>';

    // Добавляем кнопку с ссылкой на документацию API
    $htmlOutput .= '<br><a href="https://yoomoney.ru/transfer/myservices/http-notification" target="_blank" class="btn btn-primary">Уведомления API YooMoney</a>';

    return $htmlOutput;
}
?>
